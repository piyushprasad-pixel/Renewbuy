import React, { useState, useRef } from 'react'
import * as XLSX from 'xlsx'
import { saveAs } from 'file-saver'

export default function App() {
  const fileInputRef = useRef(null)
  const [rawJsonText, setRawJsonText] = useState('')
  const [jsonArray, setJsonArray] = useState(null)
  const [error, setError] = useState(null)
  const [sheetName, setSheetName] = useState('Sheet1')

  const [mappings, setMappings] = useState([
    { column: 'Vehicle Type', path: 'constant:Motor' },
    { column: 'Make', path: '' },
    { column: 'Model', path: '' },
    { column: 'Variant', path: '' },
    { column: 'RenewBuy MMV ID', path: '' },
    { column: 'Previous Policy No.', path: '' },
    { column: 'Fuel Type', path: '' },
    { column: 'Case Type', path: 'Policy.BusinessType' },
    { column: 'Registration No', path: '' },
    { column: 'Policy Type', path: '' },
    { column: 'Quote Response', path: '' },
    { column: 'Error Type', path: 'Error.Category' },
    { column: 'Request Response Link', path: '' }
  ])

  function getByPath(obj, path) {
    if (!path) return ''
    if (path.startsWith('constant:')) return path.replace('constant:', '')
    const parts = path.split('.')
    let cur = obj
    for (let p of parts) {
      if (cur == null) return ''
      cur = cur[p]
    }
    return cur ?? ''
  }

  function handleFileUpload(e) {
    const f = e.target.files?.[0]
    if (!f) return
    const reader = new FileReader()
    reader.onload = (ev) => {
      const text = ev.target.result
      setRawJsonText(text)
      parseJson(text)
    }
    reader.readAsText(f)
  }

  function parseJson(text) {
    setError(null)
    try {
      const parsed = JSON.parse(text)
      if (Array.isArray(parsed)) {
        setJsonArray(parsed)
      } else if (parsed && typeof parsed === 'object') {
        const arrKey = Object.keys(parsed).find(k => Array.isArray(parsed[k]))
        if (arrKey) setJsonArray(parsed[arrKey])
        else setJsonArray([parsed])
      } else {
        setError('JSON must be an object or array.')
        setJsonArray(null)
      }
    } catch (err) {
      setError('Invalid JSON: ' + (err.message || err))
      setJsonArray(null)
    }
  }

  function handlePasteParse() { parseJson(rawJsonText) }

  function addMapping() {
    setMappings(prev => [...prev, { column: 'New Column', path: '' }])
  }
  function updateMapping(i, key, value) {
    const copy = [...mappings]
    copy[i] = { ...copy[i], [key]: value }
    setMappings(copy)
  }
  function removeMapping(i) {
    setMappings(mappings.filter((_, idx) => idx !== i))
  }

  function buildRows() {
    if (!jsonArray) return []
    return jsonArray.map(obj => {
      const row = {}
      mappings.forEach(m => {
        row[m.column] = getByPath(obj, m.path)
      })
      return row
    })
  }

  function exportToExcel() {
    if (!jsonArray) { setError('No JSON data to export.'); return }
    const rows = buildRows()
    const ws = XLSX.utils.json_to_sheet(rows, { header: mappings.map(m => m.column) })
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, sheetName || 'Sheet1')
    const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' })
    const blob = new Blob([wbout], { type: 'application/octet-stream' })
    saveAs(blob, 'export.xlsx')
  }

  return (
    <div className="container">
      <h1>JSON → Excel Converter</h1>

      <div className="controls">
        <input ref={fileInputRef} type="file" accept="application/json" onChange={handleFileUpload} />
        <button onClick={() => fileInputRef.current?.click()}>Choose JSON</button>
        <button onClick={() => { setRawJsonText(''); setJsonArray(null); setError(null); }}>Clear</button>
      </div>

      <textarea value={rawJsonText} onChange={(e) => setRawJsonText(e.target.value)} rows={8} placeholder="Paste JSON here"></textarea>

      <div className="btn-row">
        <button onClick={handlePasteParse}>Parse JSON</button>
        <button onClick={addMapping}>Auto/add mapping</button>
      </div>

      {error && <div className="error">{error}</div>}

      <h2>Mappings</h2>
      <div className="mappings">
        {mappings.map((m, i) => (
          <div className="mapping" key={i}>
            <input value={m.column} onChange={(e) => updateMapping(i, 'column', e.target.value)} />
            <input value={m.path} onChange={(e) => updateMapping(i, 'path', e.target.value)} placeholder="dot.path.or constant:Value" />
            <button onClick={() => removeMapping(i)}>Remove</button>
          </div>
        ))}
        <button onClick={addMapping}>+ Add mapping</button>
      </div>

      <div className="sheetname">
        <label>Sheet name: <input value={sheetName} onChange={(e) => setSheetName(e.target.value)} /></label>
      </div>

      <h2>Preview (first 20)</h2>
      <div className="preview">
        <table>
          <thead>
            <tr>{mappings.map((m, i) => <th key={i}>{m.column}</th>)}</tr>
          </thead>
          <tbody>
            {jsonArray && jsonArray.length > 0 ? (
              buildRows().slice(0, 20).map((row, rIdx) => (
                <tr key={rIdx}>
                  {mappings.map((m, i) => <td key={i}>{String(row[m.column] ?? '')}</td>)}
                </tr>
              ))
            ) : (
              <tr><td colSpan={mappings.length}>No data parsed yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="actions">
        <button onClick={exportToExcel}>Export to Excel</button>
        <button onClick={() => {
          if (!jsonArray) { setError('No JSON data to export.'); return }
          const rows = buildRows()
          const ws = XLSX.utils.json_to_sheet(rows, { header: mappings.map(m => m.column) })
          const csv = XLSX.utils.sheet_to_csv(ws)
          const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
          saveAs(blob, 'export_preview.csv')
        }}>Download CSV preview</button>
      </div>

      <div className="tip">Tip: Use dot notation for nested properties (e.g. "Policy.BusinessType") and <code>constant:Value</code> for fixed values.</div>
    </div>
  )
}
