# JSON → Excel Converter (React + Plain CSS)

This is a minimal React + Vite project with plain CSS styling that converts JSON to Excel using SheetJS.

## How to run locally

1. Install dependencies
```bash
npm install
```

2. Run dev server
```bash
npm run dev
```

Open http://localhost:5173

## Build for production (create `dist` for drag & drop hosting)

```bash
npm run build
```

After running `npm run build` a `dist/` folder is created. You can **drag & drop** the contents of `dist/` to Netlify/Cloudflare Pages or upload to any static host.

## Notes

- To host without build tools, you can deploy the project on Vercel / Netlify by connecting a Git repository — they will run the build automatically.
- The default mappings include your prescribed columns. Use `constant:Value` as a mapping path to insert fixed values (e.g., `constant:Motor`).

